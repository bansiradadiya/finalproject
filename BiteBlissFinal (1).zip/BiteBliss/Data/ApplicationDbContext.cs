﻿using BiteBliss.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;


namespace BiteBliss.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext()     //ctor shortcut for this constructor
        {

        }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> o) : base(o)  // here o stands  for options here you can replace o with any word. and <ApplicationDbContext> this file name.
        {

        }

        public DbSet<Registers> users { get; set; }
    }
}
