﻿using BiteBliss.Data;
using BiteBliss.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;

namespace BiteBliss.Controllers
{
    [Route("[action]/[controller]/{id?}")]

    public class FoodDataController : Controller
    {

        private readonly FoodDbContext DbContext;

        public FoodDataController(FoodDbContext dbContext)
        {
            this.DbContext = dbContext;
        }

        [HttpGet]
        public IActionResult FoodDataView()
        {
            IEnumerable<FoodDataModel> FoodDatass = DbContext.FoodData;   //<Registration> is model's class name and studentregisters is any name and db.student is table name in ApplicationDbContext
            return View(FoodDatass);

            
        }


        [HttpGet]
        public async Task<IActionResult> CartPage()
        {
            var cartpage = await DbContext.AddToCart.ToListAsync();
            return View(cartpage);
        }

        [HttpPost]
        public async Task<IActionResult> CartPage1(int id,int quantity, string type)
        {
            var product = await DbContext.FoodData.FirstOrDefaultAsync(p => p.Id == id);

            if (product == null)
            {
                return NotFound();
            }

            var furdata = new AddToCartModel()
            {
                Name = product.Name,
                Price = product.Price,
                //Price = totalPrice,
                ImagePath = product.ImagePath,
                Quantity = quantity,
                Type = type
            };

            await DbContext.AddToCart.AddAsync(furdata);
            await DbContext.SaveChangesAsync();

            return RedirectToAction("CartPage");
        }

        [HttpPost]
        public async Task<IActionResult> CartPage(int productId)
        {
            var cartItemToRemove = await DbContext.AddToCart.FirstOrDefaultAsync(item => item.Id == productId);

            if (cartItemToRemove != null)
            {
                DbContext.AddToCart.Remove(cartItemToRemove);
                await DbContext.SaveChangesAsync();
            }

            return RedirectToAction("CartPage");
        }


        public IActionResult Search(string query)
        {
            // Filter the list of food items based on the search query
            var filteredFoodItems = GetFilteredFoodItems(query);

            // Return the filtered list of food items to the view
            return View(filteredFoodItems);
        }

        private IEnumerable<FoodDataModel> GetFilteredFoodItems(string query)
        {
            // Implement your logic to filter the list of food items based on the search query
            // For example, you can use LINQ to filter the list of food items by name
            return DbContext.FoodData.Where(item => item.Name.Contains(query)).ToList();
        }
    }
}
