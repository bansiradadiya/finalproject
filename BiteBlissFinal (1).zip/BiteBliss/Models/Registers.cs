﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace BiteBliss.Models
{
    public class Registers
    {
        [Key]
        public int UserId { get; set; }   //prop shortcut for this properties.
        [Required]
        public string UserName { get; set; }
        [Required]
        public string UserEmail { get; set; }
        [Required]
        public string UserPassword { get; set; }
        [Required]
        public string UserLocation { get; set; }
        [Required]
        public DateTime UserDate { get; set; }
    }
}
