﻿namespace BiteBliss.CartServices
{
    public class CartService:ICartService
    {
        private List<CartItem> _cartItems;

        public CartService()
        {
            _cartItems = new List<CartItem>();
        }

        public void AddToCart(int productId, string productName, decimal productPrice, int quantity, string type)
        {
            var existingItem = _cartItems.FirstOrDefault(item => item.Id == productId);

            if (existingItem != null)
            {
                existingItem.Quantity += quantity;
            }
            else
            {
                _cartItems.Add(new CartItem { Id = productId, Name = productName, Price = productPrice, Quantity = quantity, Type = type });
            }
        }

        public List<CartItem> GetCartItems()
        {
            return _cartItems;
        }
    }
}
